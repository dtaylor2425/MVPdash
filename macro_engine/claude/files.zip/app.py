# app.py
import streamlit as st
import pandas as pd
import numpy as np
import altair as alt
from datetime import date

from src.config import CACHE_DIR, FRED_API_KEY, FRED_SERIES
from src.data_sources import fetch_prices, get_fred_cached
from src.regime import compute_regime_v3
from src.ui import (
    inject_css, sidebar_nav, safe_switch_page,
    regime_color, delta_badge_html, SCORE_LEGEND_HTML,
)

st.set_page_config(
    page_title="Macro Engine",
    page_icon="📈",
    layout="wide",
    initial_sidebar_state="expanded",
)

inject_css()

# ── Constants ─────────────────────────────────────────────────────────────────

ROTATION_TICKERS = ["XLE", "XLF", "XLK", "XLI", "XLP", "XLV", "GLD", "UUP", "IWM", "QQQ", "SPY"]
MARKET_SNAPSHOT  = ["SPY", "QQQ", "IWM", "HYG", "TLT", "UUP", "GLD", "XLE"]

# ── Helpers ───────────────────────────────────────────────────────────────────

def _nearest_before(series: pd.Series, dt: pd.Timestamp):
    s = series.dropna()
    if s.empty:
        return None
    idx = s.index[s.index <= dt]
    return pd.Timestamp(idx.max()) if len(idx) else None


def delta_over_days(series: pd.Series, days: int):
    s = series.dropna()
    if s.empty:
        return None, None, None
    end    = pd.Timestamp(s.index.max())
    end_i  = _nearest_before(s, end)
    prev_i = _nearest_before(s, end - pd.Timedelta(days=days))
    if end_i is None or prev_i is None:
        return None, None, None
    latest = float(s.loc[end_i])
    prev   = float(s.loc[prev_i])
    return latest, prev, float(latest - prev)


def pct_return_over_days(series: pd.Series, days: int):
    s = series.dropna()
    if len(s) < days + 2:
        return None
    end_i  = _nearest_before(s, s.index.max())
    prev_i = _nearest_before(s, s.index.max() - pd.Timedelta(days=days))
    if end_i is None or prev_i is None:
        return None
    a, b = float(s.loc[end_i]), float(s.loc[prev_i])
    return None if b == 0 else (a / b) - 1.0


def _component_contribution(c: dict) -> float:
    if not isinstance(c, dict):
        return 0.0
    if isinstance(c.get("contribution"), (int, float, np.floating)):
        return float(c["contribution"])
    z, w = c.get("zscore"), c.get("weight")
    if isinstance(z, (int, float, np.floating)) and isinstance(w, (int, float, np.floating)):
        return float(z) * float(w)
    return 0.0


def _trend_phrase(name: str, trend_up) -> str:
    nm = (name or "").lower()
    if trend_up is None:
        return "steady"
    if "credit" in nm or "spread" in nm:
        return "widening" if int(trend_up) == 1 else "tightening"
    if "dollar" in nm or "usd" in nm:
        return "strengthening" if int(trend_up) == 1 else "weakening"
    return "rising" if int(trend_up) == 1 else "falling"

# ── Data loading ──────────────────────────────────────────────────────────────

@st.cache_data(ttl=6 * 60 * 60, show_spinner=False)
def load_current_regime():
    if not FRED_API_KEY:
        raise RuntimeError("FRED_API_KEY is not set")
    macro = get_fred_cached(FRED_SERIES, FRED_API_KEY, CACHE_DIR, cache_name="fred_macro").sort_index()
    px = fetch_prices(list(dict.fromkeys(ROTATION_TICKERS + MARKET_SNAPSHOT)), period="5y")
    if px is None or px.empty:
        px = pd.DataFrame()
    else:
        px = px.sort_index()
    regime = compute_regime_v3(macro=macro, proxies=px, lookback_trend=63, momentum_lookback_days=21)
    return regime, macro, px

# ── Business logic ────────────────────────────────────────────────────────────

def build_dynamic_drivers(regime_obj, macro, px):
    drivers = []
    comps = getattr(regime_obj, "components", None)
    if isinstance(comps, dict) and comps:
        rows = []
        for k, c in comps.items():
            if not isinstance(c, dict):
                continue
            nm      = c.get("name", k)
            contrib = _component_contribution(c)
            rows.append((nm, contrib, c.get("trend_up"), c.get("zscore")))
        rows = sorted(rows, key=lambda x: abs(x[1]), reverse=True)
        for nm, contrib, trend_up, z in rows[:3]:
            direction = "supportive" if contrib >= 0 else "drag"
            trend     = _trend_phrase(nm, trend_up)
            ztxt      = "" if z is None or pd.isna(z) else f"z {float(z):.2f}"
            subtitle  = f"{trend} • {direction}" + (f" • {ztxt}" if ztxt else "")
            drivers.append((str(nm), subtitle))

    if len(drivers) < 3 and isinstance(macro, pd.DataFrame) and not macro.empty:
        if "hy_oas" in macro.columns:
            _, _, dlt = delta_over_days(macro["hy_oas"], 7)
            if dlt is not None:
                drivers.append(("Credit conditions", "tightening" if dlt < 0 else "widening"))
        if isinstance(px, pd.DataFrame) and not px.empty and "IWM" in px.columns:
            r_iwm = pct_return_over_days(px["IWM"], 21)
            if r_iwm is not None:
                drivers.append(("Breadth proxy", "small caps leading" if r_iwm > 0 else "small caps lagging"))

    drivers = drivers[:3]
    return drivers or [("Drivers unavailable", "Regime engine returned no components")]


def build_allocation_tilt(regime_obj):
    alloc  = getattr(regime_obj, "allocation", None)
    stance = {}
    if isinstance(alloc, dict):
        stance = alloc.get("stance", {}) if isinstance(alloc.get("stance", {}), dict) else {}
    out = []
    for k in ["Equities", "Credit", "Duration", "USD", "Commodities"]:
        v = stance.get(k)
        if v is not None:
            out.append((k, str(v)))
    return out


def build_key_risk(regime_obj):
    comps = getattr(regime_obj, "components", None)
    if isinstance(comps, dict) and comps:
        rows = []
        for k, c in comps.items():
            if not isinstance(c, dict):
                continue
            nm     = c.get("name", k)
            contrib = _component_contribution(c)
            z       = c.get("zscore")
            rows.append((nm, contrib, z))
        rows.sort(key=lambda x: x[1])
        nm, contrib, z = rows[0]
        ztxt = "" if z is None or pd.isna(z) else f"z {float(z):.2f}"
        if contrib < 0:
            return f"Primary risk is {nm} staying adverse" + (f" ({ztxt})" if ztxt else "")
        return f"Primary risk is {nm} reversing against the signal" + (f" ({ztxt})" if ztxt else "")
    return "Primary risk is regime momentum reversing on a growth or credit shock."


def build_weekly_macro_changes(macro):
    items = []
    if not isinstance(macro, pd.DataFrame) or macro.empty:
        return items
    if "hy_oas" in macro.columns:
        latest, prev, dlt = delta_over_days(macro["hy_oas"], 7)
        if dlt is not None:
            items.append(("Credit spreads (HY OAS)", prev, latest, dlt, "tighter" if dlt < 0 else "wider"))
    if "y10" in macro.columns and "y2" in macro.columns:
        curve = (macro["y10"] - macro["y2"]).dropna()
        latest, prev, dlt = delta_over_days(curve, 7)
        if dlt is not None:
            items.append(("Curve (10y minus 2y)", prev, latest, dlt, "steeper" if dlt > 0 else "flatter"))
    if "real10" in macro.columns:
        latest, prev, dlt = delta_over_days(macro["real10"], 7)
        if dlt is not None:
            items.append(("Real 10y", prev, latest, dlt, "higher" if dlt > 0 else "lower"))
    if "dollar_broad" in macro.columns:
        latest, prev, dlt = delta_over_days(macro["dollar_broad"], 7)
        if dlt is not None:
            items.append(("Dollar broad", prev, latest, dlt, "stronger" if dlt > 0 else "weaker"))
    return items


def build_weekly_snapshot_tables(macro, px):
    macro_rows, mkt_rows = [], []
    for name, prev, cur, dlt, _lab in build_weekly_macro_changes(macro):
        macro_rows.append({"Metric": name, "Level": cur, "Weekly change": dlt})
    if isinstance(px, pd.DataFrame) and not px.empty:
        for t in MARKET_SNAPSHOT:
            if t not in px.columns:
                continue
            r = pct_return_over_days(px[t], 7)
            if r is not None:
                mkt_rows.append({"Asset": t, "Weekly change": 100.0 * float(r)})
    macro_df = pd.DataFrame(macro_rows)
    mkt_df   = pd.DataFrame(mkt_rows).sort_values("Weekly change", ascending=False) if mkt_rows else pd.DataFrame()
    return macro_df, mkt_df


def load_home_state():
    regime_obj, macro, px = load_current_regime()
    try:
        last_updated = macro.index.max().date()
    except Exception:
        last_updated = date.today()

    regime     = getattr(regime_obj, "label",          "Unknown")
    score      = int(getattr(regime_obj, "score",      0))
    confidence = getattr(regime_obj, "confidence",     "Unknown")
    momentum   = getattr(regime_obj, "momentum_label", "Unknown")

    allocation_tilt = build_allocation_tilt(regime_obj)
    weekly_changes  = build_weekly_macro_changes(macro)
    drivers         = build_dynamic_drivers(regime_obj, macro, px)
    key_risk        = build_key_risk(regime_obj)
    macro_df, mkt_df = build_weekly_snapshot_tables(macro, px)

    return {
        "last_updated":    last_updated,
        "regime":          regime,
        "score":           score,
        "confidence":      confidence,
        "momentum":        momentum,
        "allocation_tilt": allocation_tilt,
        "weekly_changes":  weekly_changes,
        "drivers":         drivers,
        "key_risk":        key_risk,
        "macro_snapshot":  macro_df,
        "market_snapshot": mkt_df,
        "macro":           macro,
        "px":              px,
        "regime_obj":      regime_obj,
    }


@st.cache_data(show_spinner=False)
def compute_rs_heatmap(period: str = "1y") -> pd.DataFrame:
    tickers   = ["GLD", "XLE", "XLP", "XLI", "IWM", "RSP", "HYG", "TLT", "UUP", "QQQ", "XLK", "XLF", "XLV"]
    base      = "SPY"
    px = fetch_prices(list(dict.fromkeys([base] + tickers)), period=period)
    if px is None or px.empty or base not in px.columns:
        return pd.DataFrame(index=tickers, columns=["1w", "1m", "3m"], data=np.nan)

    px   = px.dropna(how="all")
    horiz = {"1w": 5, "1m": 21, "3m": 63}
    out  = pd.DataFrame(index=tickers, columns=list(horiz.keys()), dtype=float)
    b    = px[base].dropna()

    for t in tickers:
        if t not in px.columns:
            continue
        s   = px[t].dropna()
        idx = s.index.intersection(b.index)
        if len(idx) < 90:
            continue
        s, bb = s.loc[idx], b.loc[idx]
        for lab, n in horiz.items():
            if len(idx) <= n:
                out.loc[t, lab] = np.nan
            else:
                out.loc[t, lab] = float((s.iloc[-1] / s.iloc[-1-n]) - (bb.iloc[-1] / bb.iloc[-1-n]))
    return out


def leaders_laggards(rs_df, horizon):
    s = rs_df[horizon].dropna().sort_values(ascending=False)
    return s.head(5), s.tail(5)


# ── Page guard ────────────────────────────────────────────────────────────────

if not FRED_API_KEY:
    st.error("FRED_API_KEY is not set. Add it as an environment variable.")
    st.stop()

sidebar_nav(active="Home")
home = load_home_state()

chip = home["regime"]
dot  = regime_color(chip)
score_val = home["score"]

# ── Score band colour ─────────────────────────────────────────────────────────
if score_val >= 60:
    score_color = "#1f7a4f"
elif score_val < 40:
    score_color = "#b42318"
else:
    score_color = "#6b7280"

# ═══════════════════════════════════════════════════════════════════════════════
# TOPBAR
# ═══════════════════════════════════════════════════════════════════════════════

c1, c2 = st.columns([2.2, 1.0], vertical_alignment="center")
with c1:
    st.markdown(
        f"""
        <div class="me-topbar">
          <div style="display:flex; justify-content:space-between; align-items:center; gap:12px; flex-wrap:wrap;">
            <div>
              <div class="me-title">Macro Engine</div>
              <div class="me-subtle">Market regime and rotation signals</div>
            </div>
            <div class="me-chip">
              <span class="me-dot" style="background:{dot}"></span>
              <span>{chip}</span>
            </div>
          </div>
        </div>
        """,
        unsafe_allow_html=True,
    )
with c2:
    st.markdown(
        f"<div class='me-subtle' style='text-align:right;'>Last updated: {home['last_updated']}</div>",
        unsafe_allow_html=True,
    )

# ═══════════════════════════════════════════════════════════════════════════════
# NAV TILES
# ═══════════════════════════════════════════════════════════════════════════════

nav_defs = [
    ("Home",             "Overview and summary",          None),
    ("Macro charts",     "Rates, credit, liquidity, risk","pages/2_Macro_Charts.py"),
    ("Regime deep dive", "Notes, deltas, components",     "pages/1_Regime_Deep_Dive.py"),
    ("Drivers",          "Narrative and chart links",     "pages/5_Drivers.py"),
    ("Ticker drilldown", "RS, MAs, setups",               "pages/3_Ticker_Detail.py"),
]

nav_cols = st.columns(5, gap="small")
for i, (title, desc, path) in enumerate(nav_defs):
    with nav_cols[i]:
        with st.container(border=True):
            st.markdown(f"<div class='me-nav-title'>{title}</div>", unsafe_allow_html=True)
            st.markdown(f"<div class='me-nav-desc'>{desc}</div>", unsafe_allow_html=True)
            st.markdown("")
            if title == "Home":
                st.button("Here", use_container_width=True, disabled=True, key=f"topnav_{i}")
            elif st.button("Open", use_container_width=True, key=f"topnav_{i}"):
                safe_switch_page(path)

st.markdown("")

# ═══════════════════════════════════════════════════════════════════════════════
# KPI ROW
# ═══════════════════════════════════════════════════════════════════════════════

h1, h2, h3, h4 = st.columns([1.0, 1.15, 1.2, 1.0], gap="large")

with h1:
    with st.container(border=True):
        st.markdown("<div class='me-rowtitle'>Macro score</div>", unsafe_allow_html=True)
        st.markdown(
            f"<div class='me-kpi' style='color:{score_color};'>{score_val}</div>",
            unsafe_allow_html=True,
        )
        # Score legend – always visible so new users understand the scale
        st.markdown(SCORE_LEGEND_HTML, unsafe_allow_html=True)
        st.markdown(
            f"""
            <div style="display:flex; gap:6px; flex-wrap:wrap; margin-top:10px;">
              <span class="me-pill">Confidence: {home['confidence']}</span>
              <span class="me-pill">Momentum: {str(home['momentum']).lower()}</span>
            </div>
            """,
            unsafe_allow_html=True,
        )
        st.markdown("")
        if st.button("Open score breakdown", use_container_width=True, key="btn_score"):
            safe_switch_page("pages/1_Regime_Deep_Dive.py")

with h2:
    with st.container(border=True):
        st.markdown("<div class='me-rowtitle'>Key drivers</div>", unsafe_allow_html=True)
        for i, (title, sub) in enumerate(home["drivers"], start=1):
            st.markdown(
                f"""
                <div class="me-li">
                  <div>
                    <div class="me-li-name">{i}. {title}</div>
                    <div class="me-li-sub">{sub}</div>
                  </div>
                </div>
                """,
                unsafe_allow_html=True,
            )
        st.markdown("")
        if st.button("Open drivers", use_container_width=True, key="btn_drivers"):
            safe_switch_page("pages/5_Drivers.py")

with h3:
    with st.container(border=True):
        st.markdown("<div class='me-rowtitle'>What changed this week</div>", unsafe_allow_html=True)
        if home["weekly_changes"]:
            # Metrics where a rise is BAD (spreads)
            INVERSE_METRICS = {"credit spreads", "hy oas", "spread"}
            for name, prev, cur, delta, label in home["weekly_changes"]:
                is_inverse = any(k in name.lower() for k in INVERSE_METRICS)
                badge      = delta_badge_html(delta, inverse=is_inverse)
                st.markdown(
                    f"""
                    <div class="me-li">
                      <div>
                        <div class="me-li-name">{name}</div>
                        <div class="me-li-sub">{prev:.2f} → {cur:.2f} ({label})</div>
                      </div>
                      <div class="me-li-right">{badge}</div>
                    </div>
                    """,
                    unsafe_allow_html=True,
                )
        else:
            st.caption("Weekly changes unavailable.")
        st.markdown("")
        if st.button("Open weekly details", use_container_width=True, key="btn_weekly"):
            safe_switch_page("pages/1_Regime_Deep_Dive.py")

with h4:
    with st.container(border=True):
        st.markdown("<div class='me-rowtitle'>Key risk</div>", unsafe_allow_html=True)
        st.markdown(
            f"<div style='font-size:13px; color:rgba(0,0,0,0.72); line-height:1.4;'>{home['key_risk']}</div>",
            unsafe_allow_html=True,
        )
        st.markdown("")
        if st.button("Open macro charts", use_container_width=True, key="btn_macro"):
            safe_switch_page("pages/2_Macro_Charts.py")

st.markdown("")

# ═══════════════════════════════════════════════════════════════════════════════
# ROTATION HEATMAP
# ═══════════════════════════════════════════════════════════════════════════════

with st.container(border=True):
    st.markdown("<div class='me-rowtitle'>Leadership vs SPY</div>", unsafe_allow_html=True)

    rs = compute_rs_heatmap(period="1y")

    top_controls = st.columns([1.0, 1.0, 2.0, 1.2], gap="medium")
    with top_controls[0]:
        horizon = st.radio("Focus", ["1w", "1m", "3m"], horizontal=True, index=1, key="rs_focus")
    with top_controls[1]:
        view = st.radio("View", ["Heatmap", "Leaders / laggards"], horizontal=True, index=0, key="rs_view")
    with top_controls[2]:
        leaders, laggards = leaders_laggards(rs, horizon)
        ltxt = ", ".join(leaders.index.tolist()[:2]) if len(leaders) else "n/a"
        gtxt = ", ".join(laggards.index.tolist()[:2]) if len(laggards) else "n/a"
        st.markdown(
            f"<div class='me-subtle'>Takeaway</div>"
            f"<div style='font-weight:900;color:rgba(0,0,0,0.85);font-size:13px;'>"
            f"<span style='color:#1f7a4f;'>↑ {ltxt}</span> &nbsp;|&nbsp; "
            f"<span style='color:#b42318;'>↓ {gtxt}</span></div>",
            unsafe_allow_html=True,
        )
    with top_controls[3]:
        if st.button("Open macro charts", use_container_width=True, key="btn_flows_to_macro"):
            safe_switch_page("pages/2_Macro_Charts.py")

    rs_long = (
        rs.reset_index()
        .melt(id_vars="index", var_name="Horizon", value_name="RS")
        .rename(columns={"index": "Ticker"})
        .dropna()
    )
    rs_long_h = rs_long[rs_long["Horizon"] == horizon]

    if view == "Heatmap":
        heat = (
            alt.Chart(rs_long_h)
            .mark_rect(cornerRadius=6)
            .encode(
                x=alt.X("Horizon:N", title=None),
                y=alt.Y("Ticker:N", sort=alt.SortField(field="RS", order="descending"), title=None),
                color=alt.Color("RS:Q", title="RS", scale=alt.Scale(scheme="redblue")),
                tooltip=["Ticker", "Horizon", alt.Tooltip("RS:Q", format=".3f")],
            )
            .properties(height=300)
        )
        st.altair_chart(heat, use_container_width=True)
    else:
        leaders, laggards = leaders_laggards(rs, horizon)
        cL, cR = st.columns([1, 1], gap="large")
        with cL:
            st.markdown("**Leaders**")
            for t, v in leaders.items():
                label = f"{t}  {v*100:+.1f}%"
                if st.button(label, use_container_width=True, key=f"lead_{horizon}_{t}"):
                    st.session_state["selected_ticker"] = t
                    safe_switch_page("pages/3_Ticker_Detail.py")
        with cR:
            st.markdown("**Laggards**")
            for t, v in laggards.items():
                label = f"{t}  {v*100:+.1f}%"
                if st.button(label, use_container_width=True, key=f"lag_{horizon}_{t}"):
                    st.session_state["selected_ticker"] = t
                    safe_switch_page("pages/3_Ticker_Detail.py")

st.markdown("")

# ═══════════════════════════════════════════════════════════════════════════════
# WEEKLY SNAPSHOT TABLE
# ═══════════════════════════════════════════════════════════════════════════════

with st.container(border=True):
    st.markdown("<div class='me-rowtitle'>Weekly snapshot</div>", unsafe_allow_html=True)
    tab1, tab2 = st.tabs(["Macro", "Markets"])

    with tab1:
        macro_df = home["macro_snapshot"]
        if isinstance(macro_df, pd.DataFrame) and not macro_df.empty:
            show = macro_df.copy()
            for c in ["Level", "Weekly change"]:
                if c in show.columns:
                    show[c] = pd.to_numeric(show[c], errors="coerce")
            st.dataframe(show, use_container_width=True, hide_index=True)
        else:
            st.caption("Macro snapshot unavailable.")

    with tab2:
        mkt_df = home["market_snapshot"]
        if isinstance(mkt_df, pd.DataFrame) and not mkt_df.empty:
            show = mkt_df.copy()
            if "Weekly change" in show.columns:
                show["Weekly change"] = pd.to_numeric(show["Weekly change"], errors="coerce")
            st.dataframe(show, use_container_width=True, hide_index=True)
            st.caption("Weekly change is percent return over the last 7-day window.")
        else:
            st.caption("Market snapshot unavailable.")

    st.markdown("")
    if st.button("Open regime deep dive", use_container_width=True, key="btn_weekly_bottom"):
        safe_switch_page("pages/1_Regime_Deep_Dive.py")

st.markdown("")

# ═══════════════════════════════════════════════════════════════════════════════
# REGIME TILT + WHY THIS REGIME
# ═══════════════════════════════════════════════════════════════════════════════

b1, b2 = st.columns([1.0, 1.2], gap="large")

with b1:
    with st.container(border=True):
        st.markdown("<div class='me-rowtitle'>Regime and tilt</div>", unsafe_allow_html=True)
        st.markdown(
            f"<div style='font-size:18px;font-weight:900;margin-bottom:10px;color:{score_color};'>"
            f"{home['regime']}</div>",
            unsafe_allow_html=True,
        )
        if home["allocation_tilt"]:
            for k, v in home["allocation_tilt"]:
                # colour-code over/under/neutral
                vc = v.lower()
                if "overweight" in vc:
                    badge_cls = "me-badge-green"
                elif "underweight" in vc:
                    badge_cls = "me-badge-red"
                else:
                    badge_cls = "me-badge-neutral"
                st.markdown(
                    f"""
                    <div class="me-li">
                      <div>
                        <div class="me-li-name">{k}</div>
                        <div class="me-li-sub">Suggested stance</div>
                      </div>
                      <span class="me-badge {badge_cls}">{v}</span>
                    </div>
                    """,
                    unsafe_allow_html=True,
                )
        else:
            st.caption("Allocation tilt unavailable.")

with b2:
    with st.container(border=True):
        st.markdown("<div class='me-rowtitle'>Why this regime</div>", unsafe_allow_html=True)
        comps = getattr(home["regime_obj"], "components", None)
        if isinstance(comps, dict) and comps:
            rows = []
            for k, c in comps.items():
                if not isinstance(c, dict):
                    continue
                nm = c.get("name", k)
                rows.append({"Component": str(nm), "Contribution": float(_component_contribution(c))})
            comp = pd.DataFrame(rows).sort_values("Contribution", ascending=False)

            ch = (
                alt.Chart(comp)
                .mark_bar(cornerRadiusTopLeft=5, cornerRadiusTopRight=5,
                          cornerRadiusBottomLeft=5, cornerRadiusBottomRight=5)
                .encode(
                    y=alt.Y("Component:N", sort="-x", title=None),
                    x=alt.X("Contribution:Q", title=None),
                    color=alt.condition(
                        alt.datum.Contribution > 0,
                        alt.value("#1f7a4f"),
                        alt.value("#b42318"),
                    ),
                    tooltip=["Component", alt.Tooltip("Contribution:Q", format=".2f")],
                )
                .properties(height=240)
            )
            st.altair_chart(ch, use_container_width=True)
        else:
            st.caption("Component contributions unavailable.")
        st.markdown("")
        if st.button("Open component detail", use_container_width=True, key="btn_components"):
            safe_switch_page("pages/1_Regime_Deep_Dive.py")

st.markdown("")

# ═══════════════════════════════════════════════════════════════════════════════
# BOTTOM NAV TILES
# ═══════════════════════════════════════════════════════════════════════════════

tiles = st.columns(5, gap="small")
tile_defs = [
    ("Macro charts",     "Rates, credit, liquidity, risk", "pages/2_Macro_Charts.py"),
    ("Ticker drilldown", "RS, MAs, setup features",        "pages/3_Ticker_Detail.py"),
    ("Regime deep dive", "Notes, deltas, components",      "pages/1_Regime_Deep_Dive.py"),
    ("Drivers",          "Narrative and chart links",      "pages/5_Drivers.py"),
    ("Score",            "Breakdown and history",          "pages/1_Regime_Deep_Dive.py"),
]

for i, (t, d, path) in enumerate(tile_defs):
    with tiles[i]:
        with st.container(border=True):
            st.markdown(f"<div style='font-weight:800;font-size:13px;color:rgba(0,0,0,0.85);'>{t}</div>", unsafe_allow_html=True)
            st.markdown(f"<div class='me-subtle'>{d}</div>", unsafe_allow_html=True)
            st.markdown("")
            if st.button("Open", use_container_width=True, key=f"tile_open_{i}"):
                safe_switch_page(path)

st.markdown("<div style='height:48px;'></div>", unsafe_allow_html=True)
